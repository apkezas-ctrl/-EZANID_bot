# EZA File Converter Bot

Telegram polling bot for PDF/Image conversion.

Render Background Worker:
- Build: `pip install -r requirements.txt`
- Start: `python main.py`
- Environment: `BOT_TOKEN` = BotFather token

Never put the real BOT_TOKEN in GitHub.
